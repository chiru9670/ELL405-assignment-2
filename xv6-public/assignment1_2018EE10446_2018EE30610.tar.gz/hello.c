#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
	printf(1, "Henlo World!\n");
	exit();
	return 0;
}
